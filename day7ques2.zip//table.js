function printTable(){
var num=Number(prompt("Enter a no"));
var i;
for(i=1;i<=10;i++){
  
const hTag= document.getElementById('hprint');
   hTag.innerHTML+= num+"*"+i+"="+ (num*i) + "<br/>" 
  }
}
printTable();

