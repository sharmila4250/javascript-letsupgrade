function show(){
const name=prompt("Enter a name");
const title=document.getElementById('title');
title.innerText="Welcome"+" "+name;
}
show();

const ctime=document.getElementById('time');
function clock(){
  let date=new Date();
  let time=date.toLocaleString();
  ctime.innerText=time;
}
setInterval(clock, 1000);


 function myfunction() {
   var element = document.getElementById('mode');
   element.classList.toggle('dark');
   }
 myfunction();